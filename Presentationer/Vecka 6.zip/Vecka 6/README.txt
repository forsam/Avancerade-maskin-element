G�r en fil som kan g�ra en linj�risering av funktionen!! F(Rpm, Torque)!!
