given.wheelRadius = 0.15; %[m]
given.distance = 1630;    %[m]
given.meanSpeed = 25/3.6; %[m/s]
given.endTime = given.distance/given.meanSpeed; %[s]
given.carMass = 400;      %[kg]

bearing.torque = 2;
bearing.force = bearing.torque/given.wheelRadius;

airResistance.Cd = 0.25;
airResistance.As = 2*1.225;
airResistance.force =@(v) 0.5.*airResistance.Cd.*airResistance.As.*v.^2;
