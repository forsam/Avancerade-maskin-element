%run prepare the data
prepareData

% given values for the race
givenValues

% start The Race
startRace